# CienciaDatosFinanzas2023_05
Repo en GitHub para la clase FZ4026 "Ciencia de Datos Aplicada a las Finanzas" de la maestría de Business Analytics del EGADE School of Business.
